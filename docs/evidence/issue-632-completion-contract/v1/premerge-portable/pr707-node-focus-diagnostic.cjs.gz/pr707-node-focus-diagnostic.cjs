const {app,BrowserWindow}=require('electron');
app.whenReady().then(async()=>{
 const w=new BrowserWindow({show:false,width:500,height:350});
 await w.loadURL('data:text/html,<div id="drag" style="position:absolute;left:100px;top:100px;width:50px;height:100px;background:blue"></div><script>window.events=[];for(const t of ["pointerdown","pointermove","pointerup","gotpointercapture","lostpointercapture"])document.addEventListener(t,e=>events.push({type:t,buttons:e.buttons,x:e.clientX,target:e.target.id,trusted:e.isTrusted,pointer:e.pointerId}));drag.onpointerdown=e=>drag.setPointerCapture(e.pointerId);</script>');
 w.show();app.focus({steal:true});w.focus();w.webContents.focus();
 await new Promise(r=>setTimeout(r,500));
 console.log(JSON.stringify({visible:w.isVisible(),windowFocused:w.isFocused(),contentsFocused:w.webContents.isFocused(),documentFocused:await w.webContents.executeJavaScript('document.hasFocus()')}));
 w.webContents.sendInputEvent({type:'mouseMove',x:120,y:150});
 w.webContents.sendInputEvent({type:'mouseDown',x:120,y:150,button:'left',clickCount:1});
 await new Promise(r=>setTimeout(r,100));
 w.webContents.sendInputEvent({type:'mouseMove',x:210,y:150,modifiers:['leftButtonDown']});
 await new Promise(r=>setTimeout(r,100));
 w.webContents.sendInputEvent({type:'mouseUp',x:210,y:150,button:'left',clickCount:1});
 await new Promise(r=>setTimeout(r,100));
 console.log(JSON.stringify(await w.webContents.executeJavaScript('window.events')));
 w.close();app.quit();
});
