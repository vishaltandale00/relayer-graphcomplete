import { app } from "electron";
import { createHash } from "node:crypto";
let n=0;
app.on('browser-window-created',(_event,window)=>{
 const id=++n;const contents=window.webContents;
 for(const method of ['executeJavaScript','capturePage']){
  const original=contents[method].bind(contents);
  contents[method]=async(...args)=>{
   const started=Date.now();const metadata={id,method,visible:window.isVisible(),size:window.getContentSize(),codeHash:method==='executeJavaScript'?createHash('sha256').update(String(args[0])).digest('hex'):null,paint:method==='executeJavaScript'&&String(args[0]).includes('requestAnimationFrame')};
   const timer=setTimeout(()=>process.stdout.write('FIRST_MESSAGE_AWAIT '+JSON.stringify(metadata)+'\n'),1000);
   try {const result=await original(...args);if(Date.now()-started>1000)process.stdout.write('FIRST_MESSAGE_RESOLVED '+JSON.stringify({...metadata,elapsedMs:Date.now()-started})+'\n');return result;}
   finally{clearTimeout(timer);}
  };
 }
});
await import('/private/tmp/relayer-interactive-inputs-v1-merge/scripts/test-desktop-first-message.mjs');
